package com.example.crash_direct

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
